<?php

namespace WPMDB\Queue\Exceptions;

use Exception;

class ConnectionNotFoundException extends Exception {
	//
}
