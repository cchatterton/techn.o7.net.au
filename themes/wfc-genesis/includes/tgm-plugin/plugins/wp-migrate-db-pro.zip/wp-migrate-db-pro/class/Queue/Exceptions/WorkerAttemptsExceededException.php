<?php

namespace WPMDB\Queue\Exceptions;

use Exception;

class WorkerAttemptsExceededException extends Exception {
	//
}
